import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { WeatherReportdetailsComponent } from './weather-reportdetails/weather-reportdetails.component';
import { RegisteruserComponent } from './registeruser/registeruser.component';
import { provideHttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';


const routes: Routes = [
  { path: 'weather-reportdetails', component: WeatherReportdetailsComponent }, // Define route to UserComponent
];

@NgModule({
  declarations: [
    AppComponent,
    WeatherReportdetailsComponent,
    RegisteruserComponent
  ],
  
  imports: [
    BrowserModule,HttpClientModule,
    AppRoutingModule,FormsModule,RouterModule.forRoot(routes)
  ],
  providers: [provideHttpClient()],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component } from '@angular/core';
import { RegisterUser } from '../registerUser';
import { ActivatedRoute } from '@angular/router';
import { WeatherreportService } from '../weatherreport.service';

@Component({
  selector: 'app-registeruser',
  standalone: false,
  templateUrl: './registeruser.component.html',
  styleUrl: './registeruser.component.css'
})
export class RegisteruserComponent {
  username: string = 'Dasari Gaaru...'; 
  registerUser : RegisterUser;
  constructor(private route: ActivatedRoute,private weatherreportService: WeatherreportService,registerUser : RegisterUser) {
    this.registerUser = registerUser; 
  }

  ngOnInit(): void {
     this.registerUser = new RegisterUser();
     this.weatherreportService.registerUser(this.registerUser).subscribe( data => {
    // this.registerUser = data;
     });
  }

}

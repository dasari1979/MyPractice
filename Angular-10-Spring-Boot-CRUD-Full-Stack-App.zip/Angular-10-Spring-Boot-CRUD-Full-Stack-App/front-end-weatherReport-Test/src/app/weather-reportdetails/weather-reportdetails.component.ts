import { Component, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WeatherreportService } from '../weatherreport.service';
import { WeatherReport } from '../weatherreport';
import { NgForm } from '@angular/forms';
interface HtmlElement {
  tag: string;
  attributes: { [key: string]: string };
  children: (string | HtmlElement)[];
}

@Component({
  selector: 'app-weather-reportdetails',
  standalone: false,
  template: `<div>
        <h1> Hello {{name}} how are you ? </h1>
        <h2> Welcome to interviewbit ! </h2>
    </div>`
})

export class WeatherReportdetailsComponent implements OnInit {
  name : string = "Dasari";
  parentData: string = 'Hello from Parent Component!';
  postalCode : number = 0;
  pinNumber : number = 0;
  weatherreport: string = '';
  jsonResult: any;
  constructor(private route: ActivatedRoute, private weatherreportService: WeatherreportService) {
    console.log("Entered into constructor...");
   // this.weatherreport = new String();
   }
  ngOnInit(): void {
     this.postalCode = this.route.snapshot.params['postalCode'];
     console.log("Inside ngOnInit...");
  //    this.weatherreportService.getWeatherReportDetails(560103).subscribe( data => {
  //  //  this.weatherreport = data;
  //    console.log("Inside ngOnInit...");
  //    console.log(data);
  //    });
  }
  clickMe() {
    console.log("Hai");
    }
    onSubmit(textValue: string) {
      if (Number(textValue) != 0) {
        console.log("Before method call... form value:  "+textValue);
        this.weatherreportService.getWeatherReportDetails(Number(textValue)).subscribe( data => {
        this.weatherreport = data;
        const jsonString = this.convertHtmlToJson(data);
      //  console.log("Inside onSubmit..."+jsonString);
       const _jsonString = JSON.stringify(jsonString);
        console.log("...End...");
        this.jsonResult = JSON.parse(_jsonString);
        console.log(this.jsonResult);
        console.log("End of the details...");
        });
      }
    }  
    convertHtmlToJson(htmlString: string): any {
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlString, 'text/html');
    
      const body = doc.body;
    
      const parseElement = (element: Element): any => {
        const obj: any = {
          tag: element.tagName.toLowerCase(),
          attributes: {},
          children: []
        };
    
        // Get attributes
        Array.from(element.attributes).forEach(attr => {
          obj.attributes[attr.name] = attr.value;
        });
    
        // Get child nodes
        element.childNodes.forEach(node => {
          if (node.nodeType === Node.TEXT_NODE) {
            const text = node.textContent?.trim();
            if (text) {
              obj.children.push(text);
            }
          } else if (node.nodeType === Node.ELEMENT_NODE) {
            obj.children.push(parseElement(node as Element));
          }
        });
    
        return obj;
      };
    
      const jsonOutput: HtmlElement[] = [];
      body.childNodes.forEach(node => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          jsonOutput.push(parseElement(node as Element));
        }
      });
    
      return jsonOutput;
    }
    
}

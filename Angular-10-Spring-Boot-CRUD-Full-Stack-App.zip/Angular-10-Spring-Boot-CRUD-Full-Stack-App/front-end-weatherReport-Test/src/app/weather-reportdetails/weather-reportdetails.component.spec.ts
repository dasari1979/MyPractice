import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WeatherReportdetailsComponent } from './weather-reportdetails.component';

describe('WeatherReportdetailsComponent', () => {
  let component: WeatherReportdetailsComponent;
  let fixture: ComponentFixture<WeatherReportdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WeatherReportdetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WeatherReportdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

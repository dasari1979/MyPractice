import { Component,Input  } from '@angular/core';
import { Router } from '@angular/router';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})

export class AppComponent {
  @Input() childData: string = ""; // Declare the input property
  constructor(private router: Router) {
    console.log("Inside Constructor...");
  }
  homeText : String = 'Dasari';
  title = 'Front-end-weatherReport-Test....';
  clickMe() {
  console.log("Hai");
  }
  isUserRoute(): boolean {
    return this.router.url === '/weather-reportdetails';
  }
}

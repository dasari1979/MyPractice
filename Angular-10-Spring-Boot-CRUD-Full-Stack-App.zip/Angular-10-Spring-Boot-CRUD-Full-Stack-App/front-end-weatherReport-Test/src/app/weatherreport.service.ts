import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RegisterUser } from './registerUser';
import { Observable } from 'rxjs';
import { WeatherReport } from './weatherreport';

@Injectable({
  providedIn: 'root'
})
export class WeatherreportService {
  //private baseURL = "http://localhost:9090/app/auth/register";
  private baseURL = "http://localhost:8000/app/history?postalcode=";
  constructor(private httpClient: HttpClient) { }

  getWeatherReportDetails(postalCode: number): Observable<string>{
      console.log("Postal Code... "+`${this.baseURL}${postalCode}`);
      return this.httpClient.get<string>(`${this.baseURL}${postalCode}`,{ responseType: 'text' as 'json' });
  }
  registerUser(registerUser : RegisterUser){
    return this.httpClient.post(`${this.baseURL}`, registerUser);
  }
}

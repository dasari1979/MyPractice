export class WeatherReport {
    name : string = "";
    user : string = "";
	postalCode : string = "";
	temperature : string = "";
	weather : string = "";
    weatherDesc : string = "";
	tempMin : string = "";
	tempMax : number = 0; 
	pressure : number = 0; 
	humidity: number = 0; 
    createdAt : Date = new Date();
}
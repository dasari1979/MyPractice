export class RegisterUser{
    username : string = "";
    password : string = "";
}
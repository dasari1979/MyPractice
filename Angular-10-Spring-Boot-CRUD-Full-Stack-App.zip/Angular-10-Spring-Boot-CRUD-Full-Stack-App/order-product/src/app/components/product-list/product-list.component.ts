import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import { ProductServiceService } from '../../product-service.service';  // Adjusted path
import { Product } from '../../product.model';  // Correct path to the model
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-product-list',
  imports: [CommonModule,FormsModule],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css',
  
})
export class ProductListComponent implements OnInit{
  id:number = 0;
  name: string = '';
  price: number = 0;
  description:string = '';
  url:string = '';
  products: Product[] = [];

  constructor(private productService: ProductServiceService) {}
  ngOnInit(): void {
    this.productService.getAllProducts().subscribe(data => this.products = data);
  }
  addProduct() {
    if (this.name && this.price > 0) {
      this.productService.addProduct(this.name,  this.description, this.price, this.url).subscribe({
      next: (response) => {
        console.log('✅ Product saved to backend:', response);
      },
      error: (error) => {
        console.error('❌ Failed to save product:', error);
      }
      });
     // console.log("Sent request for add products: "+JSON.stringify(this.products));
      this.name = '';
      this.price = 0;
    }
  }
}

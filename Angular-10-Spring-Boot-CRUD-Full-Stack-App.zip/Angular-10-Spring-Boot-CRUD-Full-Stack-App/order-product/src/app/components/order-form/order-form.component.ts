import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from '../../product-service.service';  // Adjusted path
import { OrderServiceService } from '../../order-service.service';  // Adjusted path
import { Product } from '../../product.model';  // Correct path to the model
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-order-form',
  imports: [CommonModule,FormsModule],
  templateUrl: './order-form.component.html',
  styleUrl: './order-form.component.css'
})
export class OrderFormComponent implements OnInit{

  products: Product[] = [];
  selectedProductIds: number[] = [];
  customerName = '';

ngOnInit(): void {
    this.productService.getAllProducts().subscribe(p => this.products = p);
  }

  constructor(
    private productService: ProductServiceService,
    private orderService: OrderServiceService
  ) {}
  submitOrder(): void {
    const orderRequest = {
      customerName: this.customerName,
      orderDate: new Date(),
      productIds: this.selectedProductIds,
    };

    this.orderService.createOrder(orderRequest).subscribe(
      (request) => {
      alert('Order placed!');
      this.customerName = '';
      this.selectedProductIds = [];
      },
      (error) => {
      console.error('Error placing order:', error);
      alert('Failed to place order.');
    }
  );
  }
  onCheckboxChange(event: Event): void {
  const checkbox = event.target as HTMLInputElement;
  const value = Number(checkbox.value);

    if (checkbox.checked) {
    this.selectedProductIds.push(value);
  } else {
    const index = this.selectedProductIds.indexOf(value);
    if (index >= 0) {
      this.selectedProductIds.splice(index, 1);
    }
  }

  console.log('Selected product IDs:', this.selectedProductIds); // DEBUG
  console.log('Checked:', checkbox.checked);
  }
}

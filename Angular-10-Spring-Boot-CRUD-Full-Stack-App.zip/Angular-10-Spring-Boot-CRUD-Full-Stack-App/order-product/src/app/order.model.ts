import { Product } from './product.model';

export interface Order {
  id: number;
  customerName: string;
  products: Product[];
  total: number;
}
export interface OrderRequest {
  customerName: string;
  orderDate: Date;
  productIds: number[];
}

export interface OrderResponse {
  id: number;
  customerName: string;
  orderDate: string;
  productIds: number[];
}
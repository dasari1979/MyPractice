import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  private baseUrl = 'http://product-service:8000/products/'; // Product Service
  private products: Product[] = [];
  private productId = 1;

  constructor(private http: HttpClient) {}

  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.baseUrl);
  }
  addProduct(name: string, description:string, price: number, url: string) {

    const product: Product = { id: this.productId++, name, description, price, url };
    this.products.push(product);
    console.log('Adding products :', product);
    return this.http.post<Product>(this.baseUrl, product);
  }
}

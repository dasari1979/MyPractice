import { Component ,OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employees-list',
  standalone: false,
  templateUrl: './employees-list.component.html',
  styleUrl: './employees-list.component.css'
})
export class EmployeesListComponent implements OnInit{

//employees: Employee[];

constructor(private employeeService: EmployeeService) { }

  ngOnInit(): void {
  //  this.getEmployees();
  }
/*     getEmployees(): void {
    this.employeeService.getEmployeeList.apply(data => {
      this.employees = data;
    });
  } */
}

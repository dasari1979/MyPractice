// src/App.tsx
import { useEffect, useState } from 'react';
import { useAccount, useSignMessage } from 'wagmi';
import { ConnectButton } from '@rainbow-me/rainbowkit';

function App() {
  const { address, isConnected } = useAccount();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const loginMessage = `Login request at ${new Date().toISOString()}`;

  const { signMessage, data: signature } = useSignMessage();

  const handleLogin = async () => {
  const loginMessage = "Sign this message to log in";

  signMessage({ message: loginMessage });
  };

  useEffect(() => {
    if (isConnected && !signature) {
     // signMessage(); // Prompt wallet to sign message
    }
  }, [isConnected]);

  useEffect(() => {
    if (signature) {
      console.log('✅ Address:', address);
      console.log('📝 Signature:', signature);
      // Optionally send to backend here
      setIsLoggedIn(true);
    }
  }, [signature]);

  return (
    <div style={{ padding: 20 }}>
      <h2>RainbowKit Wallet Login</h2>
      <ConnectButton />
      {isLoggedIn && <p>✅ Logged in as: {address}</p>}
    </div>
  );
}

export default App;

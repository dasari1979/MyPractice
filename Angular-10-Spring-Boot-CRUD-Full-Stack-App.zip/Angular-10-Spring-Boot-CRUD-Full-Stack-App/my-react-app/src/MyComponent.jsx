// File: MyComponent.jsx
import React from 'react';

function MyComponent() {
  return <h2>Hello from MyComponent!</h2>;
}

export default MyComponent;

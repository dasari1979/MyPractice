import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ProductsList.css';


function ProductsList(){

  const [products, setProducts] = useState([]);
  const loadProducts = () => {
    const token = localStorage.getItem('token');
    console.log(token);
    axios.get('http://localhost:8000/products/',{
    headers: {
            Authorization: `Bearer ${token}`
          }
    })
    .then(res => {
     console.log('API Response:', res.data); //
      setProducts(res.data);
    });
  };
  useEffect(() => {
    loadProducts();
  }, []);

  return (
    <div className="product-container">
      <h3>Products</h3>
      {products.length > 0 ? (
        <div className="product-list">
          {products.map(p => (
            <div className="product-row" key={p.id}>
              <img src={p.url} alt={p.name} className="product-img" />
              <span className="product-name">{p.name}</span>
              <span className="product-description">{p.description}</span>
              <span className="product-price">${p.price}</span>
            </div>
          ))}
        </div>
      ) : (
        <p>No products available</p>
      )}
    </div>
  );
}
export default ProductsList;
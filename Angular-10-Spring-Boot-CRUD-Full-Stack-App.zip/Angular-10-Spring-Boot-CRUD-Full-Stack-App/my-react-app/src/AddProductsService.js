import axios from "axios";

const BASE_URL = "http://localhost:8000/products/";

const addProduct = (productData)=>{
try {
const response = axios.post(BASE_URL,productData);
return response.data;
}catch(error){
console.error("Error adding products...");
throw error;
}

}

export default{
addProduct,
};
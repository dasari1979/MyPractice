//import logo from './logo.svg';
import './App.css';
import React, { useEffect, useState } from 'react';
import axios from 'axios';


function ProductManager() {
  const [form, setForm] = useState({ name: '', price: '' });
  const [editingId, setEditingId] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingId) {
      axios.put(`http://localhost:8000/products/${editingId}`, form).then(() => {
        setForm({ name: '', price: '' });
        setEditingId(null);
      });
    } else {
      axios.post('http://localhost:8000/products', form).then(() => {
        setForm({ name: '', price: '' });
      });
    }
  };

  const handleEdit = (product) => {
    setForm({ name: product.name, price: product.price });
    setEditingId(product.id);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Product Manager</h2>
      <form onSubmit={handleSubmit}>
        <input
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <input
          placeholder="Price"
          type="number"
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
          required
        />
        <button type="submit">{editingId ? 'Update' : 'Add'} Product</button>
      </form>
    </div>
  );
}

export default ProductManager;
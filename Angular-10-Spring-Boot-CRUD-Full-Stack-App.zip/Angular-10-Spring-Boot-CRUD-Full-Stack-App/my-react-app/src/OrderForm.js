import React, { useEffect, useState } from 'react';
import axios from 'axios'; // Assuming REST APIs are used
import './OrderForm.css';
import OrderService from './OrderService';

const BASE_URL = "http://localhost:8000/products/";
const OrderForm = () => {
  const [products, setProducts] = useState([]);
  const [selectedProductIds, setSelectedProductIds] = useState([]);
  const [customerName, setCustomerName] = useState('');
  const [successMessage,setSuccessMessage] = useState('');
  const [error,setErrorMessage] = useState("");

  // Fetch products on mount
  useEffect(() => {
    axios.get(BASE_URL) // Update to match your backend
      .then(response => setProducts(response.data))
      .catch(error => console.error('Error fetching products:', error));
  }, []);

  // Handle checkbox change
  const onCheckboxChange = (e) => {
    const id = Number(e.target.value);
    setSelectedProductIds(prev =>
      e.target.checked
        ? [...prev, id]
        : prev.filter(pid => pid !== id)
    );
  };

  // Submit order
  const submitOrder = () => {

  // Basic validation
  if (customerName.trim() === '') {
    setErrorMessage('Please enter customer name.');
    setSuccessMessage('');
    return;
  }

    const order = {customerName,orderDate: new Date(),productIds: selectedProductIds,};

    OrderService.submitOrder(order)
    .then(()=>{
        setSuccessMessage(`Order for "${customerName}" placed successfully!`);
        setCustomerName('');
        setSelectedProductIds([]);
    })
    .catch(error => {
        console.error('Error placing order:', error);
        setErrorMessage('Failed to place order.');
        setSuccessMessage('');
      });
  };

return (
  <div className="order-container">
    <h2>Place Order</h2>

    <div className="field-group">
      <label className="field-label">Customer Name:</label>
      <input
        type="text"
        placeholder="Enter customer name"
        value={customerName}
        onChange={(e) => setCustomerName(e.target.value)}
        className="order-input"
      />
    </div>
    <div>
         
   <h3 style={{ textAlign: 'left', color: 'rgb(16, 95, 174)' }}>Select Products:</h3>
    </div>
    <div className="product-list">

    {products.map((product) => (
        <label key={product.id} className="product-item">
        <input
            type="checkbox"
            value={product.id}
            checked={selectedProductIds.includes(product.id)}
            onChange={onCheckboxChange}
        />
        {product.name}
        </label>
    ))}
    </div>


    <button className="submit-button" onClick={submitOrder}>
      Submit Order
    </button>

   {
    successMessage && (
       <div style={{ color: '#27ae60', marginTop: '10px', fontWeight: 'bold', fontSize: '20px'}}>
          {successMessage}
        </div>)
   }
            
       <div style={{ color: '#ff3b3f', marginTop: '10px', fontWeight: 'bold', fontSize: '20px'}}>
          {error}
        </div>

  </div>
);

};

export default OrderForm;

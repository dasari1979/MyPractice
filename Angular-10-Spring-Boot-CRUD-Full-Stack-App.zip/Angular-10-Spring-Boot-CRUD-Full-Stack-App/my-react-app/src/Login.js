import React, { useEffect,useState } from "react";


function Login({ onLogin }){
const [error, setError] = useState('');
const [email,setEmail] = useState("");
const [password,setPassword] = useState("");
const BASE_URL = "http://localhost:8000/api/login";
const handleLogin = async(e)=>{
  e.preventDefault();
  try {
/* const response= await  fetch(BASE_URL,{
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({email,password}),
             });
const data = await response.json(); */

  if(true){
// localStorage.setItem('token',data.token);
  localStorage.setItem("email", email);
  onLogin(email); 
  window.location.href = '/'
  }else{
  // alert(data.message||'Login Failed');  
  }
}catch {
  setError('Invalid credentials');
}
}
  return(
    <form onSubmit={handleLogin} style={{ textAlign: 'center', marginTop: '100px' }}>
      <input type="email" placeholder="Email" onChange={(e) => setEmail(e.target.value)} required/>
      <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} required/>
      <button type="submit">Login</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </form>
  );
}
export default Login;

/* function Application(){
const intArray=[1,2,3];
const [count,setCount] = useState(0);
const [double, setDouble] = useState([]);

const printHello = ()=>{
console.log("Hello");
const double = intArray.map(p=>{
 console.log(p*2);
 return p*2;
});
console.log(double);
setDouble(double);
};

useEffect(()=>{
printHello();
},);

return(
<div>
<button onClick={()=>setCount(count+1)}> Increment</button>
<p>Count {count}</p>
<p>Double {double.join(", ")} </p>
</div>
);
}
export default Application; */
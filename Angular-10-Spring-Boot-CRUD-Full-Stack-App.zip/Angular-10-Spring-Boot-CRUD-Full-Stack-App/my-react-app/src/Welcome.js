import React from 'react';

function Welcome() {
  return (
    <h1>Hello, world!</h1>
  );
}
export default Welcome;
import React from 'react';
import { Component } from "react";

class ClassComponent extends Component{

    constructor(props){
     super(props);
     this.state = {

        message: "Hello from ClassComponent",
     };
    }

   componentDidMount() {
   
    console.log("Component has mounted!");

   }

    render(){
     
        return(

            <div>
                <h1>Hello ClassComponent</h1>
            </div>
        );
    }
}


export default ClassComponent;
// App.js
import {
  BrowserRouter as Router,  // ✅ CORRECT
  Routes,
  Route,
  Link,
  Navigate
} from 'react-router-dom';

import React from 'react';
import ProductList from './ProductList'; 
import OrderForm from './OrderForm'; 
import AddProducts from './AddProducts';
import Login from './Login';
import { useState } from "react"

function App() {
  const [email, setEmail] = useState("");
  const [user, setUser] = useState(()=>{
  ///  const token = localStorage.getItem('token');
    const storedEmail = localStorage.getItem('email');
    console.log(email);
    return storedEmail;
  // return storedEmail ;
  });

/*   const handleLogin = (userEmail) =>{
  localStorage.setItem('email', userEmail);       // store user's email
  setEmail(userEmail);    // You can store just 'true' if you prefer   // store email from login
  } */
const handleLogin = (userEmail) => {
  localStorage.setItem('email', userEmail);
  setEmail(userEmail);
  setUser(userEmail);   // <-- this was missing
};

  const handleLogout = ()=>{
    localStorage.removeItem('token');
    localStorage.removeItem('email');
    setUser(null);
  }

    if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <Router>
      <div>
        <h1 style={{ textAlign: 'center', color: 'rgb(16, 95, 174)' }}>Welcome to the Product Manager</h1>
         <p style={{ textAlign: 'center',color: '#27ae60',fontWeight: 'bold', fontSize: '20px'}}>Logged in as: {user}</p>

        
        {/* Navigation Links */}
        <nav style={{ display: 'flex', justifyContent: 'center', gap: '20px', marginBottom: '20px' }}>
          <Link to="/">Product List</Link>
          <Link to="/add-product">Add Product</Link>
          <Link to="/order-form">Order Form</Link>
           <button onClick={handleLogout}style={{background: 'none',border: 'none',color: 'blue',cursor: 'pointer',textDecoration: 'underline',
               fontSize: '16px',
             padding: 0}}>Logout</button>
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<ProductList />} />
          <Route path="/add-product" element={<AddProducts/>} />
          <Route path="/order-form" element={<OrderForm/>} />
                    {/* Redirect to home for unknown routes */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </Router>
    
  );
}

export default App;
import axios from 'axios';

const BASE_URL = 'http://localhost:9000/orders/'; // adjust endpoint if needed

const submitOrder = async (order) => {
  return axios.post(BASE_URL, order);
};

export default {
  submitOrder,
};

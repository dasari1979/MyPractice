import React from "react";
import { useState } from "react"
import AddProductsService from "./AddProductsService";
import './AddProducts.css';

const AddProducts= () => {
const [name,setName] = useState("");
const [price,setPrice] = useState(0);
const [description,setDescription] = useState("");
const [url,setUrl] = useState("");
const [successMessage, setSuccessMessage] = useState("");
const [error,setError] = useState("");

const handleSubmit = async (e)=>{
 e.preventDefault(); 
const product = {name, price, description, url};
try{
await AddProductsService.addProduct(product);
console.log("Added Product");
}catch(error){
console.log("Error while adding product");
throw error;
}
if(name.trim()){
    setSuccessMessage(`Product "${name}" Added Successfully`+successMessage);
  }else {
    setError(`Please add product name...`);
}
}

return (
<div className="form-container">
    <h2>Add a New Product</h2>
 <form onSubmit={handleSubmit}>
    <input type="text" placeholder="Product Name" value={name} onChange={(e) => setName(e.target.value)} required/>
    <input type="number" placeholder="Product Price" value={price} onChange={(e) => setPrice(Number(e.target.value))} required/>
    <input type="text" placeholder="Product Description" value={description} onChange={(e) => setDescription(e.target.value)}required/>
    <input type="text" placeholder="Image URL" value={url} onChange={(e) => setUrl(e.target.value)} required/>
    <button type="submit">Add Product</button>
</form>
{
    successMessage && (
       <div style={{ color: '#27ae60', marginTop: '10px', fontWeight: 'bold', fontSize: '20px'}}>
          {successMessage}
        </div>)}
            
       <div style={{ color: '#ff3b3f', marginTop: '10px', fontWeight: 'bold', fontSize: '20px'}}>
          {error}
        </div>
    </div>
  );
}
export default AddProducts;
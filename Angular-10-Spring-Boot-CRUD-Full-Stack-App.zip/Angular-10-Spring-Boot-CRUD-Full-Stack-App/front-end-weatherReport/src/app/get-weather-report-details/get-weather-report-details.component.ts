import { Component } from '@angular/core';

@Component({
  selector: 'app-get-weather-report-details',
  imports: [],
  templateUrl: './get-weather-report-details.component.html',
  styleUrl: './get-weather-report-details.component.css'
})
export class GetWeatherReportDetailsComponent {
   weatherReport = 'Weather Report';
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetWeatherReportDetailsComponent } from './get-weather-report-details.component';

describe('GetWeatherReportDetailsComponent', () => {
  let component: GetWeatherReportDetailsComponent;
  let fixture: ComponentFixture<GetWeatherReportDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GetWeatherReportDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetWeatherReportDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

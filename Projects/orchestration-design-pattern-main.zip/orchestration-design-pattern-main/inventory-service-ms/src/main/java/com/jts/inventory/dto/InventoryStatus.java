package com.jts.inventory.dto;

public enum InventoryStatus {
	AVAILABLE,
	UNAVAILABLE;
}

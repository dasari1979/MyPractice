package com.jts.payment.dto;

public enum PaymentStatus {
	PAYMENT_APPROVED,
	PAYMENT_REJECTED
}

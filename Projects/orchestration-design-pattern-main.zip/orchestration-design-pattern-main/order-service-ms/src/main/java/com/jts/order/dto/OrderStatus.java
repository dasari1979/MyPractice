package com.jts.order.dto;

public enum OrderStatus {

    ORDER_CREATED,
    ORDER_CANCELLED,
    ORDER_COMPLETED

}
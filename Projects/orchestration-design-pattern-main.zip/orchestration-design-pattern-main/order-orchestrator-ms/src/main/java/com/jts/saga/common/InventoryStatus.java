package com.jts.saga.common;

public enum  InventoryStatus {
    AVAILABLE,
    UNAVAILABLE;
}

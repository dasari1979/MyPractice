package com.jts.saga.service;

public enum WorkflowStepStatus {
    PENDING,
    COMPLETE,
    FAILED;
}

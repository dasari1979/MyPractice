package com.jts.saga.common;

public enum  PaymentStatus {
    PAYMENT_APPROVED,
    PAYMENT_REJECTED;
}

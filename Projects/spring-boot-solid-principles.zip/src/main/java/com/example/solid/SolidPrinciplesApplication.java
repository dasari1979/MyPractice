package com.example.solid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolidPrinciplesApplication {
    public static void main(String[] args) {
        SpringApplication.run(SolidPrinciplesApplication.class, args);
    }
}

package com.example.solid.service.interfaces;

public interface PaymentGateway {
    String pay(double amount);
}

package com.example.solid.service;

import com.example.solid.service.interfaces.PaymentGateway;
import org.springframework.stereotype.Component;

@Component
public class PaypalPayment implements PaymentGateway {

    @Override
    public String pay(double amount) {
        return "Payment of ₹" + amount + " processed through Paypal.";
    }
}

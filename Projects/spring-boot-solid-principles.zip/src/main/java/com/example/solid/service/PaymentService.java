package com.example.solid.service;

import com.example.solid.service.interfaces.PaymentGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    @Autowired
    private PaymentGateway paymentGateway;

    public String processPayment(double amount) {
        return paymentGateway.pay(amount);
    }
}

package com.example.threadpool.controller;

import com.example.threadpool.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.ExecutionException;

@RestController
public class DemoController {

    @Autowired
    private DemoService demoService;

    @GetMapping("/async-task")
    public String runAsyncTask() throws ExecutionException, InterruptedException {
        return demoService.executeAsyncTask(1).get();
    }

    @GetMapping("/callable-task")
    public String runCallableTask() throws Exception {
        return demoService.executeCallableTask();
    }
}

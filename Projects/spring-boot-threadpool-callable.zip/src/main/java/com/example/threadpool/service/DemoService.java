package com.example.threadpool.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.FutureTask;

@Service
public class DemoService {

    @Async("customThreadPool")
    public CompletableFuture<String> executeAsyncTask(int id) {
        return CompletableFuture.supplyAsync(() -> "Task Completed: " + id);
    }

    public String executeCallableTask() throws Exception {
        Callable<String> callableTask = () -> {
            Thread.sleep(1000);
            return "Callable Task Executed by: " + Thread.currentThread().getName();
        };

        FutureTask<String> futureTask = new FutureTask<>(callableTask);
        Thread thread = new Thread(futureTask);
        thread.start();

        return futureTask.get();
    }
}

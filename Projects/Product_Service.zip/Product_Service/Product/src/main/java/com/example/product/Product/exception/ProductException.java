package com.example.product.Product.exception;

public class ProductException extends Exception{
	
	
	public ProductException(String str){
		
		System.out.println("Exception Occured...");
	}

}

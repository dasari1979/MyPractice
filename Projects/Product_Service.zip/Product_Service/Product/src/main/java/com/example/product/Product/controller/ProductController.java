package com.example.product.Product.controller;

import java.awt.List;

import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.Product.entity.Product;
import com.example.product.Product.exception.ProductException;
import com.example.product.Product.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	private ProductService productService;
	@GetMapping("/")
	public java.util.List<Product> getAllProducts() {
		
		java.util.List<Product> allProducts = productService.getAllProducts();
		return allProducts;
		
	}
	
	@GetMapping("{id}")
	public Product getAllProductById(Long id) throws ProductException {
		
		Product product = productService.getAllProductbyId(id);
		if(product == null)
			throw new ProductException("Exception while getting products");
		return product;
		
	}

}

package com.example.product.Product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.product.Product.entity.Product;
import com.example.product.Product.repository.ProductRepository;

@Service
public class ProductService {

	private ProductRepository productRepository;
	
	
	public List<Product> getAllProducts(){
		
		List<Product> allProducts = productRepository.findAll();
		return allProducts;
		
	}
	
    public Product getAllProductbyId(Long id){
		
		Product allProducts = productRepository.findById(id).get();
		return allProducts;
		
	}
	
	
}

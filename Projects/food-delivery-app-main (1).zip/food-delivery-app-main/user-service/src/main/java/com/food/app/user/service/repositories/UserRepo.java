package com.food.app.user.service.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.food.app.user.service.model.Users;

@Repository
public interface UserRepo extends JpaRepository<Users, Long> {

}

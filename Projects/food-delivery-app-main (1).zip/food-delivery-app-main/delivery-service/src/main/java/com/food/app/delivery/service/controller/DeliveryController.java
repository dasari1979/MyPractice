package com.food.app.delivery.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.food.app.delivery.service.model.Delivery;
import com.food.app.delivery.service.services.DeliveryService;

@RestController
@RequestMapping("/api/deliverys")
public class DeliveryController {
	
	private final DeliveryService deliveryService;

   @Autowired
    public DeliveryController(DeliveryService deliveryService) {
        this.deliveryService = deliveryService;
    }

	// Endpoint to check if the service is running
	@RequestMapping("/health")
	public String healthCheck() {
		return "Delivery Service is running!";
	}

	// Endpoint to get delivery details
	@RequestMapping("/details")
	public String getDeliveryDetails() {
		return "Delivery details will be returned here.";
	}

	// Endpoint to create a new delivery
	@RequestMapping("/create")
	public ResponseEntity<Delivery> createDelivery(@RequestBody Delivery delivery) {
		Delivery savedDelivery = deliveryService.saveDelivery(delivery);
        return new ResponseEntity<>(savedDelivery, HttpStatus.CREATED);

	}

	// Endpoint to update delivery information
	@RequestMapping("/update")
	public String updateDelivery() {
		return "Delivery update logic will be implemented here.";
	}
}

package com.food.app.delivery.service.model;



import java.time.LocalDateTime;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Users entity class representing a user in the system.
 * 
 * @author Satheesh
 * 
 */
@Data
@NoArgsConstructor
@Entity
@Getter
@Setter
public class Delivery {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long deliveryId;
	private String orderId;
	private String userId;
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "address_id", referencedColumnName = "id")
	private Address address;
	private Status status;
	private LocalDateTime estimatedDeliveryTime;
	private LocalDateTime actualDeliveryTime;
}



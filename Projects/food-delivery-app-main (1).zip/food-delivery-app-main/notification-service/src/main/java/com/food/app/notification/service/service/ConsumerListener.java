package com.food.app.notification.service.service;


import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class ConsumerListener {
	@KafkaListener(topics = "my-topic", groupId = "notification-group")
    public void consume(String message) {
        System.out.println("Received notification: " + message);
        // Trigger SMS, Email, or Push notifications as needed
    }
}

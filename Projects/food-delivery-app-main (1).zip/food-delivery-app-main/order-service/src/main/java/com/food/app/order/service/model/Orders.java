package com.food.app.order.service.model;

//import com.food.app.user.service.model.Users;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Users entity class representing a user in the system.
 * 
 * @author Satheesh
 */

@Data
@NoArgsConstructor
@Entity
@Getter
@Setter
public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String orderName;
	private String orderDescription;
	private String orderStatus;
	private String orderDate;
	private String orderTime;
	private String orderLocation;
//	private Users user; // Assuming an order is associated with a user
	private Long userId; // Assuming an order is associated with a user by userId
	private String orderType; // Assuming an order can have a type (e.g., delivery, pickup)
	private int orderAmount; // Assuming an order has an amount associated with it
	private String orderPaymentStatus; // Assuming an order has a payment status
	private int orderQuantity; // Assuming an order has a quantity associated with it
}

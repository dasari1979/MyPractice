package com.food.app.order.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.food.app.order.service.model.Orders;
import com.food.app.order.service.services.KafkaProducerService;
import com.food.app.order.service.services.OrderService;

/**
 * 
 */
@RestController
@RequestMapping("/api/orders")
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private KafkaProducerService producerService;

//	public OrderController(KafkaProducerService producerService) {
//        this.producerService = producerService;
//    }

	
	
	// Endpoint to check if the service is running
	@RequestMapping("/health")
	public String healthCheck() {
		return "Order Service is running!";
	}

	// Endpoint to get order details
	@RequestMapping("/details")
	public String getOrderDetails() {
		return "Order details will be returned here.";
	}

	// Endpoint to create a new order
	@RequestMapping("/create")
	public String createOrder(@RequestBody Orders order) {
		Orders savedOrder = orderService.createOrder(order);
		producerService.sendMessage("my-topic", order.getOrderName());

		return "Order creation logic will be implemented here. User: " + savedOrder.getOrderName();
	}

	// Endpoint to update order information
	@RequestMapping("/update")
	public String updateOrder() {
		return "Order update logic will be implemented here.";
	}
	
}

package com.example.lockdemo;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/products")
public class ProductController {

    private final ProductRepository repository;
    private final ProductService service;

    public ProductController(ProductRepository repository, ProductService service) {
        this.repository = repository;
        this.service = service;
    }

    @PostMapping
    public Product create(@RequestBody Product product) {
        return repository.save(product);
    }

    @PutMapping("/{id}")
    public String updateStock(@PathVariable Long id, @RequestParam int stock) {
        try {
            service.updateStock(id, stock);
            return "Updated successfully";
        } catch (Exception e) {
            return "Failed due to optimistic locking";
        }
    }
}
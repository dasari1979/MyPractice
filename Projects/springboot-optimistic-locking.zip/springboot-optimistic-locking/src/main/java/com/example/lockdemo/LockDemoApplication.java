package com.example.lockdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LockDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(LockDemoApplication.class, args);
    }
}
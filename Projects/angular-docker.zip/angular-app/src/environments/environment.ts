export const environment = {
  production: false,
  productApiUrl: '/api/products/',
  orderApiUrl: '/api/orders/'
};

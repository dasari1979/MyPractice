package com.example.payment.paymentdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentdemoApplication.class, args);
	}

}

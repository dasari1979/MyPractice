package com.example.payment.paymentdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

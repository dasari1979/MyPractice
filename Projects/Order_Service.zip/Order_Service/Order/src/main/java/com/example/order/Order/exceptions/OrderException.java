package com.example.order.Order.exceptions;


public class OrderException extends Exception{

	
	public OrderException(String message){
		System.out.println("Exception while order...");
	}
	
}

package com.example.order.Order.service;

import com.example.order.Order.entity.Order;
import com.example.order.Order.repository.OrderRepository;

public class OrderService<Product> {

	
	private OrderRepository orderRepository;
	
	public Order<Product> saveOrder(Object product) {
		
	//	orderRepository.save(product);
		
		return null;
		
	}
	
}

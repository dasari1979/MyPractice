package com.example.order.Order.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.order.Order.entity.Order;

@SuppressWarnings("rawtypes")
public interface OrderRepository extends JpaRepository<Order, Long> {

}

package com.example.order.Order.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.order.Order.entity.Order;
import com.example.order.Order.exceptions.OrderException;
import com.example.order.Order.service.OrderService;

@RestController
@RequestMapping("/orders")
public class OrderController<Product> {
	
	@SuppressWarnings("rawtypes")
	@Autowired
	private OrderService orderService;
	
    @Autowired
    private RestTemplate restTemplate;
	
	@PostMapping("/")
	public Object createOrder(int id) throws OrderException{
		
		
		Object products = restTemplate.getForObject("/products/"+id, String.class);
		
		if(products == null)
			throw new  OrderException("Products not avaialble");
		
		Order orderId = orderService.saveOrder(products);
		
		return orderId;
		
	}
	
	

}

package com.food.app.notification.service.service;


import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.food.app.notification.service.event.NotificationEvent;






@Service
public class NotificationListener {
	@KafkaListener(topics = "notification-topic", groupId = "notification-group")
    public void consume(NotificationEvent event) {
        System.out.println("Received notification: " + event.getMessage());
        // Trigger SMS, Email, or Push notifications as needed
    }
}

package com.food.app.notification.service.event;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class NotificationEvent {
	private String orderId; // Optional: if the notification is related to an order
	private String userId;
    private String type; // e.g., EMAIL, SMS, PUSH
    private String message;
    private String status; // Optional: QUEUED, SENT, FAILED
    private LocalDateTime timestamp;
}

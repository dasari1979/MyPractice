# Food-delivery-app
food-delivery-app - This repository is defined for System design of food-delivery application. Developed with Java FS and cloud native.
Development technologies 
As part of application development used below technologies, AWS cloud

Language: Java 17
Backend : Spring boot ( REST, Hibernate, MySQL, MongoDB, Postgres ) 
Web service : REST
Event API : Kafka - each and every event
Architecture : Microservice ( 1. Frontend,  2. User service 3. Restaurant service etc) 
Build tool : Maven
Frontend : Angular 16
Authentication: JWT, tobe modify to AWS IAM 
Repository: Github
CI/CD : Jenkins
Deployment : Dockers, ECS, EKS ( Kubernates )
AWS - RDS ( MySQL, Postgres ), Dynamo DB (MongoDB) Keep all the database


----------------------------

🔧 **Microservices Breakdown**
	• User Service: Registration, login, JWT-based auth
	• Restaurant Service: CRUD for restaurants and menus
	• Order Service: Cart, order placement, tracking
	• Delivery Service: Assign delivery partners, status updates
	• Notification Service: Kafka consumers for push/email alert

📦 **Kafka Integration**
	• Use Kafka for:
	• Order events (placed, accepted, delivered)
	• Real-time updates to delivery partners
	• Decoupling services for scalability

🚀 **Deployment Strategy**
✅ Dockerize Each Microservice
FROM openjdk:17 COPY target/*.jar app.jar ENTRYPOINT ["java", "-jar", "app.jar"] 
✅   Use ECS for Simpler Container Management
	• Define task definitions for each service
	• Use ALB for routing
	• Store secrets in AWS Parameter Store
✅   Use EKS for Advanced Orchestration
	• Helm charts or Kubernetes manifests
	• Service mesh (e.g., Istio) for traffic control
	• Auto-scaling and rolling updates
🗄️ **Database Layer**
	• Amazon RDS (MySQL/PostgreSQL) for transactional data
	• Use JPA/Hibernate in Spring Boot
	• Enable read replicas for scalability
🔐 **JWT Authentication Flow**
	1. User logs in → receives JWT
	2. JWT passed in Authorization header
	3. Spring Security validates token
	4. Role-based access control enforced
🧪 **CI/CD Pipeline with Jenkins**
	• GitHub → Jenkins → Docker Build → Push to ECR → Deploy to ECS/EKS
	• Use buildspec.yml or Jenkinsfile
	• Integrate SonarQube for code quality checks
 

Would you like me to help scaffold the project structure or generate a sample GitHub README for this architecture? You’re building something impressive — let’s make it shine!<img width="1007" height="1253" alt="image" src="https://github.com/user-attachments/assets/e3e7c711-0404-457f-bdcd-d5e60e1f632d" />

/**
 * 
 */
package com.food.app.user.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.food.app.user.service.model.Users;
import com.food.app.user.service.services.UserService;

/**
 * 
 */
@RestController
@RequestMapping("/api/users")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	// Endpoint to check if the service is running
	@GetMapping("/health")
	public String healthCheck() {
		return "User Service is running!";
	}

	// Endpoint to get user details
	@GetMapping("/details")
	public String getUserDetails() {
		return "Users details will be returned here.";
	}

	// Endpoint to get user details
	@GetMapping("/uderId")
	public String getUser(String uderId) {
		return "Users details will be returned here.";
	}

	// Endpoint to create a new user
	@PostMapping("/create")
	public String createUser(@RequestBody Users user) {
		Users savedUser = userService.createUser(user);
		return "Users creation logic will be implemented here. User: " + savedUser.getName();
	}

	// Endpoint to update user information
	@PostMapping("/update")
	public String updateUser() {
		return "Users update logic will be implemented here.";
	}
}

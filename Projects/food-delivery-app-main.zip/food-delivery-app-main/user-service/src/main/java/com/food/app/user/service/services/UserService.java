/**
 * 
 */
package com.food.app.user.service.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.food.app.user.service.model.Users;
import com.food.app.user.service.repositories.UserRepo;

/**
 * 
 */

@Service
public class UserService {
	@Autowired
	private UserRepo userRepo;
	// Method to get user details by user ID
	public String getUserDetails(Long userId) {
		return userRepo.findById(userId)
				.map(user -> "User details: " + user)
				.orElse("User not found");
	}
	
	// Method to create a new user
	public Users createUser(Users user) {
		userRepo.saveAndFlush(user);
		return user;
	}
}

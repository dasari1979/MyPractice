package com.food.app.order.service.services;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.food.app.notification.service.event.NotificationEvent;
import com.food.app.order.service.model.Orders;
import com.food.app.order.service.repositories.OrderRepo;

@Service
public class OrderService {
	 @Autowired
	 private KafkaTemplate<String, NotificationEvent> kafkaTemplate;

//	 public void placeOrder(Orders order) {
//	        // Business logic to place order...
//
//	        NotificationEvent event = new NotificationEvent();
//	        event.setOrderId(order.getOrderId());
//	        event.setUserId(order.getUserId());
//	        event.setStatus("ORDER_PLACED");
//	        event.setMessage("Your order has been successfully placed.");
//	        event.setTimestamp(LocalDateTime.now());
//
//	        kafkaTemplate.send("notification-topic", event);
//	    }

	
	
	@Autowired
	private OrderRepo orderRepo;
	// Method to get order details by order ID
	public String getUserDetails(Long orderId) {
		return orderRepo.findById(orderId)
				.map(order -> "Order details: " + order)
				.orElse("Order not found");
	}
	
	// Method to create a new order
	public Orders createOrder(Orders order) {
		NotificationEvent event = new NotificationEvent();
        event.setOrderId(String.valueOf(order.getId()));
        event.setUserId(String.valueOf(order.getUserId()));
        event.setStatus("ORDER_PLACED");
        event.setMessage("Your order has been successfully placed.");
        event.setTimestamp(LocalDateTime.now());

        kafkaTemplate.send("notification-topic", event);
		
		orderRepo.saveAndFlush(order);
		return order;
	}
}

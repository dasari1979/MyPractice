package com.food.app.delivery.service.model;

public enum Status {
	PENDING, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
}

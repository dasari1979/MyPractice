package com.food.app.delivery.service.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.food.app.delivery.service.model.Delivery;
import com.food.app.delivery.service.repositories.DeliveryRepo;

@Service
public class DeliveryService {
	@Autowired
	private DeliveryRepo deliveryRepo;
	// Method to get delivery details by delivery ID
	public String getDeliveryDetails(Long deliveryId) {
		return deliveryRepo.findById(deliveryId)
				.map(delivery -> "Delivery details: " + delivery)
				.orElse("Delivery not found");
	}
	
	// Method to create a new delivery order
	public Delivery saveDelivery(Delivery delivery) {
		deliveryRepo.saveAndFlush(delivery);
		return delivery;
	}
}

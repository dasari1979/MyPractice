export const environment = {
  production: true,
  productApiUrl: 'http://localhost:8000/products',
  orderApiUrl: 'http://localhost:9000/orders'
};

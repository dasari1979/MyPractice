import { Routes } from '@angular/router';
import { OrderFormComponent } from "./components/order-form/order-form.component";
import { ProductListComponent } from './components/product-list/product-list.component';

export const routes: Routes = [
      { path: 'orders', component: OrderFormComponent },
      { path: 'products', component: ProductListComponent },
];

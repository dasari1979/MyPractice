import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,RouterLink
],
  //templateUrl: './app.component.html',
  styleUrl: './app.component.css',
   template: `
       <h1>Order & Product Management</h1>
    <nav>
      <a routerLink="/products">Products</a> |
      <a routerLink="/orders">Orders</a>
    </nav>
    <router-outlet></router-outlet>
    <!-- <h1>Order & Product Management</h1>
     <app-product-list></app-product-list>
     <hr />
     <app-order-form></app-order-form>
    <hr /> -->
`
})
export class AppComponent {
  title = 'order-product';
}

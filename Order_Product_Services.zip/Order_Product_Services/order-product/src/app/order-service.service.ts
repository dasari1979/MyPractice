import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { OrderResponse } from './order.model';
import { OrderRequest } from './order.model';
import { Product } from './product.model';
import { Order } from './order.model';

@Injectable({
  providedIn: 'root'
})
export class OrderServiceService {

  private products: Product[] = [];
  private orders: Order[] = [];

   private baseUrl = 'http://localhost:9000/orders/';
   constructor(private http: HttpClient) {}
    createOrder(order: OrderRequest): Observable<any> {
      alert("Added order..."+order);
    return this.http.post<any>(this.baseUrl, order);
  }

    getAllOrders(): Observable<OrderResponse[]> {
    return this.http.get<OrderResponse[]>(this.baseUrl);
  }
}

package com.task.product.service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.retry.annotation.Retryable;
import org.springframework.retry.annotation.Backoff;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.task.product.service.entity.Product;
import com.task.product.service.repository.ProductRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductService {
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	ProductRepository _productRepository;
	
	public List<Product> getAllProducts(){
		return productRepository.findAll();
		
	}
	@Transactional
	public Product getProductById(Long id){

		return productRepository.findAndLockById(id);		
	}
	@Transactional
	@Retryable(
		    retryFor = ObjectOptimisticLockingFailureException.class,
		    maxAttempts = 3,
		    backoff = @Backoff(delay = 1000, multiplier = 2)
		)
	public Product saveProducts(Product product){
		
		Product productId = productRepository.findAndLockById(product.getId());
		log.info("Locked to this id "+ productId);
		log.info("Saving product from webpage..."+product);
		
		return productRepository.save(product);
		
	}
}

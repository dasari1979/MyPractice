#!/usr/bin/env bash

host="$1"
shift
port="$1"
shift

timeout="${WAITFORIT_TIMEOUT:-60}"

for i in $(seq $timeout); do
  nc -z "$host" "$port" && echo "Connected to $host:$port" && exec "$@"
  echo "Waiting for $host:$port... ($i)"
  sleep 1
done

echo "Timeout after $timeout seconds waiting for $host:$port"
exit 1
